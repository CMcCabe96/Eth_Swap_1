import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
import Token from '../abis/Token.json'
import EthSwap from '../abis/EthSwap.json'
import Navbar from './Navbar';
import Main from './Main';



class App extends Component {

async componentWillMount(){
    await this.loadWeb3()
    await this.loadBlockchainData()
  }
// load mm account
  async loadBlockchainData() {
    const web3 = window.web3

    const accounts = await web3.eth.getAccounts()
    this.setState({ account: accounts[0]})

// dont need the whole ethBalance : ethBalance as its the same name, so can just call it once
    const ethBalance = await web3.eth.getBalance(this.state.account)
    this.setState({ ethBalance })

//create js version of the smart contract so we can interact with the solidty contract
// loads token
  const networkId = await web3.eth.net.getId()
  const tokenData = Token.networks[networkId]

// checking to see if the token address exists
  if(tokenData) {
    const token =  new web3.eth.Contract(Token.abi, tokenData.address)
    this.setState({ token })
    //getting balance of account who is connected to the blockchain - talking to the smart contract
    // call() is used to get info from the blockhain
    let tokenBalance = await token.methods.balanceOf(this.state.account).call()
    this.setState({ tokenBalance: tokenBalance.toString() })
    } else {
    window.alert('Token contract not deployed to detcted network')
  }

// Load EthSwap
  const ethSwapData = EthSwap.networks[networkId]
  if(ethSwapData) {
    const ethSwap =  new web3.eth.Contract(EthSwap.abi, ethSwapData.address)
    this.setState({ ethSwap })
    } else {
    window.alert('EthSwap contract not deployed to detected network')
  }
  }
// making sure browser is compatible with blockhain aka metamask
  async loadWeb3() {
    if (window.ethereum) {
      window.web3 = new Web3(window.ethereum)
      await window.ethereum.enable()
    }
    else if (window.web3) {
      window.web3 = new Web3(window.web3.currentProvider)
    }
    else {
      window.alert('Non-ethereum browser detected')
    }
    this.setState({ loading: false})
  }
// send() writes to the blockchain
buyTokens = (etherAmount) => {
  this.setState({ loading: true})
  this.state.ethSwap.methods.buyTokens().send({ value: etherAmount, from: this.state.account}).on('transactionHash', (hash) => {})
  this.setState({ loading: false })
}
// approving the address to sell
sellTokens = (tokenAmount) => {
  this.setState({ loading: true})
  this.state.token.methods.approve(this.state.ethSwap.address, tokenAmount).send({ from: this.state.account}).on('transactionHash', (hash) => {})
  this.state.ethSwap.methods.sellTokens(tokenAmount).send({ from: this.state.account}).on('transactionHash', (hash) => {})
  this.setState({ loading: false })
}
// gets run everytime the component is created
constructor(props) {
  super(props)
  this.state = {
    account: '',
    token: {},
    ethBalance: '0',
    tokenBalance: '0',
    ethSwap: {},
    loading: true
  }
}

// this part is creating a loading screen while we wait for the contract and rest of data to load into the webpage
  render() {
    let content
    let loading = false
    if(this.state.loading) {
    content = <p id="loader" classname="text-center">Loading...</p>
    } else {
      content = <Main
      ethBalance={this.state.ethBalance}
      tokenBalance={this.state.tokenBalance}
      buyTokens={this.buyTokens}
      sellTokens={this.sellTokens}
      />
    }
    return (
      <div>
      <Navbar account = {this.state.account} />
        <div className="container-fluid mt-5">
          <div className="row">
            <main role="main" className="col-lg-12 ml-auto mr-auto" style={{ maxWidth: '600px' }}>
              <div className="content mr-auto ml-auto">
                <a
                  href="http://www.dappuniversity.com/bootcamp"
                  target="_blank"
                  rel="noopener noreferrer"
                  >
                </a>
                {content}
              </div>
            </main>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
