const Token = artifacts.require('Token')
const EthSwap = artifacts.require('EthSwap')
// require chai javascript library
require('chai')
  .use(require('chai-as-promised'))
  .should()
//making it so 1 million token is more readable than 1000000000000000000000000
//using web3 to help do this, Wei being small ether unit
  function tokens(n) {
    return web3.utils.toWei(n, 'ether')
  }
//linking to EthSwap contract, deployer is first account which refrences first account in ganache, investor is the second account
contract('EthSwap', ([deployer, investor]) => {
let token, ethSwap
//allows token & ethSwap to be seen/used in below fucntions without having to delcare them each time with the let function
before(async () => {
token = await Token.new()
ethSwap = await EthSwap.new(token.address)
//transfer all tokens to EthSwap (1 million)
await token.transfer(ethSwap.address, tokens('1000000'))
})
//test for checking if the token has a name
  describe('Token deployment', async() => {
  it('token has a name', async () => {
      const name = await token.name()
      assert.equal(name, 'DApp Token')
    })
  })
//test for checking if the contract has a name
  describe('EthSwap deployment', async() => {
  it('contract has a name', async () => {
      const name = await ethSwap.name()
      assert.equal(name, 'EthSwap Instant Exchange')
    })
//test for checking if the contract has tokens
    it('contract has tokens', async () => {
      let balance = await token.balanceOf(ethSwap.address)
      assert.equal(balance.toString(), tokens('1000000'))
    })
    describe('Token deployment', async () => {
    })
    describe('EthSwap deployment', async () => {
    })
//accounts[1] allows us to tell whos purchasing ether, value (represents the msg.value in EthSwsap.sol) is telling us how much ether that they are sending when they purchase the tokens
//changed accounts[1] to investor as there is two accounts defined in contract abover 1. Deployer 2. Investor
    describe('buyTokens()', async() => {
      let result

      before(async () => {
        //purchase tokens before each example
        result = await  ethSwap.buyTokens({ from: investor, value : web3.utils.toWei('1', 'ether')})

      })
      it('Allows user to instantly purchase tokens from ethSwap for a fixed price', async () => {
        // Check investor received the tokens after purchase
        let investorBalance = await token.balanceOf(investor)
        assert.equal(investorBalance.toString(), tokens('100'))

        // Check ethSwap balance after purchase, 999900 is because 1 million - 100 = 999900
        let ethSwapBalance
        ethSwapBalance = await token.balanceOf(ethSwap.address)
        assert.equal(ethSwapBalance.toString(), tokens('999900'))
        // Check ethSwap balance after sending
        ethSwapBalance = await web3.eth.getBalance(ethSwap.address)
        assert.equal(ethSwapBalance.toString(), web3.utils.toWei('1', 'Ether'))

        const event = result.logs[0].args
        assert.equal(event.account, investor)
        assert.equal(event.token, token.address)
        assert.equal(event.amount.toString(), tokens('100').toString())
        assert.equal(event.rate.toString(), '100')
      })
    })

    describe('sellTokens()', async() => {
      let result

      before(async () => {
        // Investor must approve tokens before the purcahse, calling approve function in the token sol.
        await token.approve(ethSwap.address, tokens('100'), { from :investor})
        // Once approved, Investor sells tokens
        result = await ethSwap.sellTokens(tokens('100'), { from :investor})
      })
      it('Allows user to instantly sell tokens to ethSwap for a fixed price', async () => {
        // Check investor balance after purcahse - we are checking '0' as they sold them in the above test
        let investorBalance = await token.balanceOf(investor)
        assert.equal(investorBalance.toString(), tokens('0'))

        // Check ethSwap balance after purchase, 1000000 as they have been sold back
        let ethSwapBalance
        ethSwapBalance = await token.balanceOf(ethSwap.address)
        assert.equal(ethSwapBalance.toString(), tokens('1000000'))
        // Check ethSwap balance after sending
        ethSwapBalance = await web3.eth.getBalance(ethSwap.address)
        assert.equal(ethSwapBalance.toString(), web3.utils.toWei('0', 'Ether'))

        // check logs to ensure event 'TokensSold' was emitted with the correct data
        const event = result.logs[0].args
        assert.equal(event.account, investor)
        assert.equal(event.token, token.address)
        assert.equal(event.amount.toString(), tokens('100').toString())
        assert.equal(event.rate.toString(), '100')

        // FAILURE: invesotr cant sell more tokens that they have
        await ethSwap.sellTokens(tokens('500'), { from: investor}).should.be.rejected;
      })

    })
  })
})
